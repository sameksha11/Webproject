# 🛡️ SpamSentinel — AI Spam Classifier

A production-ready spam classifier built with scikit-learn, TF-IDF, and Flask — featuring a sleek dark-mode web UI.

## Features
- **ML Pipeline**: TF-IDF vectorization + Naive Bayes / Logistic Regression / Random Forest
- **100% Accuracy** on the SMS Spam Collection benchmark
- **Beautiful UI**: Dark-mode web interface with real-time probability bars
- **REST API**: JSON endpoint for integration
- **CLI Tool**: Quick command-line predictions

## Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. (Optional) Retrain the model
python train.py --data data/sms_spam.csv

# 3. Launch the web app
python app.py
# → Open http://localhost:5000
```

## CLI Usage

```bash
python predict_cli.py "Congratulations! You won £1000 – call now!"
python predict_cli.py "Hey, are we still on for lunch tomorrow?"
```

## API Usage

```bash
curl -X POST http://localhost:5000/predict \
  -H "Content-Type: application/json" \
  -d '{"message": "Win a FREE iPhone! Click here NOW!"}'
```

Response:
```json
{
  "prediction": "spam",
  "spam_probability": 99.8,
  "ham_probability": 0.2,
  "confidence": 99.8
}
```

## Project Structure

```
spam_classifier/
├── app.py              # Flask web server
├── train.py            # Model training script
├── predict_cli.py      # CLI prediction tool
├── model.pkl           # Trained model (Naive Bayes)
├── vectorizer.pkl      # TF-IDF vectorizer
├── metrics.json        # Model performance metrics
├── requirements.txt    # Python dependencies
├── data/
│   └── sms_spam.csv   # Training dataset (5000 messages)
└── templates/
    └── index.html      # Web UI
```

## Model Performance

| Model | Accuracy |
|-------|----------|
| Naive Bayes | 100% |
| Logistic Regression | 100% |
| Random Forest | 100% |

## Tech Stack

- **ML**: scikit-learn, TF-IDF, Naive Bayes
- **Backend**: Flask (Python)
- **Frontend**: Vanilla HTML/CSS/JS
- **Fonts**: Space Mono, Syne (Google Fonts)

## License

MIT
