from flask import Flask, request, jsonify, render_template
import pickle, re, json, os

app = Flask(__name__)

# Load model and vectorizer
BASE = os.path.dirname(__file__)
with open(f"{BASE}/model.pkl", "rb") as f:
    model = pickle.load(f)
with open(f"{BASE}/vectorizer.pkl", "rb") as f:
    vectorizer = pickle.load(f)
with open(f"{BASE}/metrics.json") as f:
    metrics = json.load(f)

def preprocess(text):
    text = text.lower()
    text = re.sub(r'http\S+|www\S+', ' url ', text)
    text = re.sub(r'\d+', ' num ', text)
    text = re.sub(r'[^\w\s]', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

@app.route("/")
def index():
    return render_template("index.html", metrics=metrics)

@app.route("/predict", methods=["POST"])
def predict():
    data = request.json
    message = data.get("message", "").strip()
    if not message:
        return jsonify({"error": "No message provided"}), 400
    
    clean = preprocess(message)
    vec = vectorizer.transform([clean])
    pred = model.predict(vec)[0]
    proba = model.predict_proba(vec)[0]
    classes = list(model.classes_)
    spam_prob = proba[classes.index("spam")]
    ham_prob  = proba[classes.index("ham")]
    
    return jsonify({
        "prediction": pred,
        "spam_probability": round(float(spam_prob) * 100, 1),
        "ham_probability":  round(float(ham_prob)  * 100, 1),
        "confidence": round(float(max(spam_prob, ham_prob)) * 100, 1),
    })

@app.route("/metrics")
def get_metrics():
    return jsonify(metrics)

if __name__ == "__main__":
    app.run(debug=True, port=5000)
