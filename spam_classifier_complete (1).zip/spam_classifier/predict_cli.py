"""Quick CLI prediction tool. Usage: python predict_cli.py "Your message here" """
import sys, pickle, re, os

BASE = os.path.dirname(os.path.abspath(__file__))

def preprocess(text):
    text = text.lower()
    text = re.sub(r'http\S+|www\S+', ' url ', text)
    text = re.sub(r'\d+', ' num ', text)
    text = re.sub(r'[^\w\s]', ' ', text)
    return re.sub(r'\s+', ' ', text).strip()

with open(f"{BASE}/model.pkl","rb") as f: model = pickle.load(f)
with open(f"{BASE}/vectorizer.pkl","rb") as f: vec = pickle.load(f)

msgs = sys.argv[1:] if len(sys.argv) > 1 else [
    "Congratulations! You won £1000. Call NOW!",
    "Hey, want to grab coffee tomorrow?"
]

print(f"\n{'─'*60}")
for msg in msgs:
    clean = preprocess(msg)
    v = vec.transform([clean])
    pred = model.predict(v)[0]
    proba = model.predict_proba(v)[0]
    classes = list(model.classes_)
    spam_p = proba[classes.index("spam")]
    icon = "🚨" if pred=="spam" else "✅"
    print(f"{icon} [{pred.upper():4s}] {spam_p:.0%} spam | {msg[:55]}")
print(f"{'─'*60}\n")
