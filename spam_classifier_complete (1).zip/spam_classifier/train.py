"""
Train the spam classifier.
Usage: python train.py [--data path/to/data.csv]
Saves model.pkl, vectorizer.pkl, metrics.json to the same directory.
"""
import argparse, re, pickle, json, os
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score

def preprocess(text):
    text = str(text).lower()
    text = re.sub(r'http\S+|www\S+', ' url ', text)
    text = re.sub(r'\d+', ' num ', text)
    text = re.sub(r'[^\w\s]', ' ', text)
    return re.sub(r'\s+', ' ', text).strip()

def train(data_path):
    print(f"Loading data from {data_path}...")
    df = pd.read_csv(data_path)
    df['clean'] = df['message'].apply(preprocess)
    print(f"  {len(df)} samples | {df['label'].value_counts().to_dict()}")

    X_train, X_test, y_train, y_test = train_test_split(
        df['clean'], df['label'], test_size=0.2, random_state=42, stratify=df['label'])

    tfidf = TfidfVectorizer(ngram_range=(1,2), max_features=10000, sublinear_tf=True)
    X_tr = tfidf.fit_transform(X_train)
    X_te = tfidf.transform(X_test)

    candidates = {
        "Naive Bayes": MultinomialNB(alpha=0.1),
        "Logistic Regression": LogisticRegression(max_iter=300, C=5, random_state=42),
    }
    results = {}
    for name, clf in candidates.items():
        clf.fit(X_tr, y_train)
        acc = accuracy_score(y_test, clf.predict(X_te))
        results[name] = (clf, acc)
        print(f"  {name}: {acc:.4f}")

    best_name, (best_model, best_acc) = max(results.items(), key=lambda x: x[1][1])
    print(f"\nBest: {best_name} ({best_acc:.4f})")

    base = os.path.dirname(os.path.abspath(__file__))
    with open(f"{base}/model.pkl", "wb") as f: pickle.dump(best_model, f)
    with open(f"{base}/vectorizer.pkl", "wb") as f: pickle.dump(tfidf, f)
    metrics = {"best_model": best_name, "accuracy": round(best_acc*100,2),
               "models": {k: round(v[1]*100,2) for k,v in results.items()}}
    with open(f"{base}/metrics.json","w") as f: json.dump(metrics, f, indent=2)
    print("Saved model.pkl, vectorizer.pkl, metrics.json")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="data/sms_spam.csv")
    args = parser.parse_args()
    train(args.data)
